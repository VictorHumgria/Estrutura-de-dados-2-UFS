/*
 * balanceLine.h
 *
 *  Modified on: Jul, 2023
 *      Author: raphael oliveira
 */


#include <stdio.h> /* define FILE */
#include <stdlib.h>

void balanceLine(FILE *fMestre, FILE *fTransacao, FILE *fNovoMestre, FILE *fErro){
	//TODO
	//implementar o algoritmo do Balance Line
}

